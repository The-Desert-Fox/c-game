#include <string>

int countInventory();
