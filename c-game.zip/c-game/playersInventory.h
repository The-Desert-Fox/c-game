#include <string>
#include "countInventory.h"
using namespace std;

void playersInventory();
