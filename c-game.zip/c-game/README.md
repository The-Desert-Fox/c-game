# c-game

Room 1
Kitchen. Spot key on the counter top. open door.
Opens to hallway. Three doors, a bookcase and a fireplace. Front door locked. 2 keyholes.

Go right. Solve puzzle to get a key.
Go left. Solve another puzzle to get a key.

Open front door. END.
