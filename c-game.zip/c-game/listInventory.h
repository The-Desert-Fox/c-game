#include <string>

void listInventory();
