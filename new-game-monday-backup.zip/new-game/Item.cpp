#include "Item.h"
using namespace std;

Item::Item(){

}

Item::Item(int n_id, std::string n_type, std::string n_itemDescription){
  id = n_id;
  type = n_type;
  itemDescription = n_itemDescription;
}

void Item::show(int n_id, std::string n_type, std::string n_itemDescription){
  id = n_id;
  type = n_type;
  itemDescription = n_itemDescription;
}

void Item::use(){

}

void Item::examine(std::string a){
  cout << itemDescription << endl;
}

std::ostream& operator<<(std::ostream& out, const Item& y){
  return out<< y.type << endl << y.itemDescription << endl;
}

std::istream& operator>>(std::istream& in, const Item& r){
  return in;
}

Item::~Item(){

}
