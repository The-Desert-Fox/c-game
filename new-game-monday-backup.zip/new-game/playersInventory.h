#include <string>
#include <vector>
//#include "Item.h"
#include "inventoryHelper.h"
using namespace std;

void playersInventory(vector<Item> inventoryItems, string textfile1);
