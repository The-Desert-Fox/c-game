#include <vector>
#include <string>
#include <sstream>
#include <fstream>
#include <iostream>
using namespace std;

class Item{
  private:
    int id;
    std::string type;
    std::string itemDescription;

  public:
    Item();
    Item(int n_id, std::string n_type, std::string n_itemDescription);
    void show(int n_id, std::string n_type, std::string n_itemDescription);
    void use(); // Pass reference to inventory vector
    void examine(std::string a); // Read out description
    friend std::ostream& operator<<(std::ostream& out, const Item& o);
    friend std::istream& operator>>(std::istream& in, const Item& o);
    ~Item();
};
