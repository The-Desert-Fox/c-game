#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <vector>
#include "Item.h"
#include "Room.h"
#include "playersInventory.h"
#include "inventoryHelper.h"
using namespace std;

int main(){
  string textfile1 = "inventroyItems.txt";
  vector<Item> inventoryItems;
  vector<Room> rooms;
  int count = countInventory(textfile1);
  ++count;

  //MENU
  string x, ret;
	cout << "What would you like to do?" << endl;
  cout << "Enter Here : ";
	cin >> x;

  // Converting input data to lower case
  std::transform(x.begin(), x.end(),x.begin() , ::tolower);
	if(x == "inventory"){
    cout << endl;
		playersInventory(inventoryItems, textfile1);
	}
  else if(x == "describe"){
    //for describing the room
  }
}
