#include <string>
#include <vector>
using namespace std;

void listInventory(vector<Item> inventoryItems, string textfile1);
int countInventory(string textfile1);
