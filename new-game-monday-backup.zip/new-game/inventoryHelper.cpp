#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "item.h"
#include "inventoryHelper.h"

using namespace std;

void listInventory(vector<Item> inventoryItems, string textfile1){
  ifstream myfile;
  myfile.open(textfile1);
  int count = countInventory(textfile1);

  Item i2, i3;
  //i2.id = 2;
  //i2.type = "Copper Key";
  //i2.itemDescription = "A Key Made From Copper.";
  i2.show(2, "Copper Key", "A Key Made From Copper.");
  i3.show(3, "Red Key", "A Key That Has Been Painted Red.");
  cout << i2 << endl << i3 << endl;

  //for(int a=0; a<count; ++a){
    //cout << "item " << a << " is in your inventory" << endl;
    //textfile1 >> ;
    //cout <<  << endl;
  //}
  myfile.close();
  //return "";
}

int countInventory(string textfile1){
  ifstream myfile;
  myfile.open("inventoryItems.txt");

  int count = 0;
  string line;
  while(getline(myfile, line))
  {
    ++count;
  }
  count = count / 3; // how many lines does a single inventory item take (id, name, description)
  myfile.close();

  return count;
}
