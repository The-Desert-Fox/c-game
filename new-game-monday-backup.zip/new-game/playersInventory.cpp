#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <vector>
#include "Item.h"
#include "playersInventory.h"
#include "inventoryHelper.h"
using namespace std;

void playersInventory(vector<Item> inventoryItems, string textfile1){
  ifstream myfile;
  myfile.open(textfile1);
  // Count's the amount of items in the players inventory
  int count = countInventory(textfile1);
  cout << "There are " << count << " Items in your inventory." << endl;

  // Let the Player choose what to do
  string choice, itemName, ret;
  cout << "What would you like to do?" << endl;
  cout << "Enter Here : ";
	cin >> choice;

  // Converting input data to lower case
  std::transform(choice.begin(), choice.end(),choice.begin() , ::tolower);


  if(choice == "list"){
    ret = "Your Inventory consists of...";
    cout << ret << endl;

    listInventory(inventoryItems, textfile1);
    cout << endl;
    playersInventory(inventoryItems, textfile1);
  }
  // Use (itemName) || Examine (itemName) || Read (itemName)
  //USE POINTERS
	else if(choice == "use"){
    ret = "you chose to type ";
    cout << ret << choice << endl;
    //if(itemName =){
    //  ret = use(Inventory, textfile1);
    //  cout << ret << endl;
    //}
    cout << endl;
    playersInventory(inventoryItems, textfile1);
	}
  else if(choice == "examine"){
    ret = "you chose to type ";
    cout << ret << choice << endl;
    //if(itemName =){
    //  ret = examine(Inventory, textfile1);
    //  cout << ret << endl;
    //}
    cout << endl;
    playersInventory(inventoryItems, textfile1);
  }
  else if(choice == "?" || choice == "help"){
    cout << "Inventory Help\n" << "list : lists your current inventory.\n" << "use : use an item.\n" << "examine : examine an item.\n" << "exit : exit inventory.\n" << endl;
    playersInventory(inventoryItems, textfile1);
  }
  else if(choice == "exit" || choice == "quit"){
    cout << "Exiting inventory" << endl;
  }
}
