#include <string>

class Wall{
  private:
    std::string wallDescription;
    std::string [] wallItems;
    int locks;
    String locktype;

  public:
    int roomobjects;
    Room();
    Room(Wall north, Wall south,Wall east, Wall west);
    look(std::string a); //wall Description
    take(std::string a);
}
