#include "Wall.h";
#include <string>

class Room{
  private:
    int id;
    Wall north;
    Wall south;
    Wall east;
    Wall west;
    std::string name;

  public:
    std::string roomDescription;
    int roomobjects;
    Room();
    Room(Wall north, Wall south,Wall east, Wall west, std::string name);
    look(std::string a);
}
