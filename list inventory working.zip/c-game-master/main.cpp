#include <iostream>
#include <fstream>
#include <string>
using namespace std;
void Inventory();
int countInventory();

int main(){
  string textfile1 = "inventroyItems.txt";
  int count = countInventory();
  ++count;

  //MENU
  string x, ret;
	cout << "What would you like to do?" << endl;
  cout << "Enter Here : ";
	cin >> x;
	if(x == "inventory" || x == "Inventory" || x == "INVENTORY"){
		Inventory();
	}
}
void Inventory(){
  ifstream textfile1;
  textfile1.open("inventoryItems.txt");
  // Count's the amount of items in the players inventory
  int count = countInventory();
  cout << "there are " << count << " Items in your inventory." << endl;
  // Display's the Players Inventory contents
  //string list = listInventory();

  // Let the Player choose what to do
  string choice, itemName, ret;
  cout << "What would you like to do?" << endl;
  cout << "Enter Here : ";
	cin >> choice;
  // Use (itemName) || Examine (itemName) || Read (itemName)
  //USE POINTERS
	if(choice == "use" || choice == "Use" || choice == "USE"){
    ret = "you chose to type ";
    cout << ret << choice << endl;

    //if(itemName =){
    //  ret = use(Inventory, textfile1);
    //  cout << ret << endl;
    //}
	}
  else if(choice == "examine" || choice == "Examine" || choice == "EXAMINE"){
    ret = "you chose to type ";
    cout << ret << choice << endl;

    //if(itemName =){
    //  ret = examine(Inventory, textfile1);
    //  cout << ret << endl;
    //}
  }
}
int countInventory(){
  ifstream textfile1;
  textfile1.open("inventoryItems.txt");

  int count = 0;
  string line;
  while(getline(textfile1, line)){
    ++count;
  }
  count=count/3; // how many lines does a single inventory item take (id, name, description)
  textfile1.close();
  return count;
}
//string listInventory(){
//  ifstream textfile1;
//  textfile1.open("inventoryItems.txt");
//  int count = countInventory();

//  for(int i=0; i<count; ++i){
//    textfile1 >> Items.at(i).inventoryItemID >> Items.at(i).inventoryItemName >> Items.at(i).inventoryItemDescription;
//    cout << i.inventoryItemID << ", "
//         << i.inventoryItemName << ", "
//         << i.inventoryItemDescription << endl;
//  }
//   textfile1.close();
//   return "";
//}
